# Developer Analytics Handoff

## Common event envelope
`event_id` UUID; `event_name`; `event_datetime` UTC ISO-8601; `user_id`; nullable `session_id`; `schema_version`; `source_system`; `idempotency_key`; `event_status`; domain properties. Server events are authoritative for wallet/reward/withdrawal state.

## Acceptance tests
1. Every event has unique event_id and valid event_name. 2. Required user_id and event_datetime are present. 3. Timestamp parses as UTC. 4. Enum values are allow-listed. 5. Duplicate idempotency keys do not double-post financial effects. 6. Referenced user/session/object exists or is explicitly nullable. 7. Task/reward/withdrawal timestamps follow valid state order. 8. Amounts use decimal precision and approved units. 9. Schema changes are versioned and backward-compatible or migrated. 10. Failed validation is quarantined with reason and trace ID.

Event tracking plan contains 35 proposed events. They are not asserted to be implemented.
