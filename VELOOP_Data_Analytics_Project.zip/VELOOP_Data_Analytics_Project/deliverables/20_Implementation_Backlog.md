# Implementation Backlog

Prioritized items and acceptance criteria are in `Implementation_Backlog.xlsx`. P0: identity/event contract, wallet ledger, withdrawal state machine, event envelope. P1: task/reward instrumentation, referral ledger, automated quality tests, curated analytics layer. P2: dashboard MVP, governance/access reviews and metric/schema change log. Priorities reflect data integrity and dependency risk, not confirmed company commitments.
