# Data Pipeline Proposal

Recommended practical architecture: product services → validated event/API or batch exports → immutable raw landing (restricted) → schema and quality validation → curated conformed tables (users, sessions, events, task attempts, rewards ledger, wallet ledger, withdrawals, referrals) → semantic KPI layer → dashboard. Start with managed storage/warehouse already approved by the organization; avoid introducing costly infrastructure without scale requirements.

Controls: schema versioning, idempotent ingestion, late-arriving data handling, UTC timestamps, deduplication, lineage, freshness monitoring, quarantine, reconciliation and controlled backfills. Separate raw PII from pseudonymous analytics views.
