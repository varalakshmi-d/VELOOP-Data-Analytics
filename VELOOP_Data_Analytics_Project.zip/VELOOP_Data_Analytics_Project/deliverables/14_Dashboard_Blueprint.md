# Dashboard Blueprint

Build seven role-oriented views after metric sign-off: **Executive Overview** (active users, registrations, onboarding, engagement trends, data freshness); **User Analytics** (lifecycle funnel, cohorts, acquisition, verification); **Engagement** (DAU/WAU/MAU, sessions, feature adoption, task funnel); **Rewards** (issued/claimed/expired/reversed and XP movements); **Wallet** (credits/debits, balance reconciliation, exceptions); **Withdrawals** (request funnel, paid/failure status, processing time); **Referrals** (invites, attribution, qualification).

Every tile must show metric definition, date range, timezone, data freshness, source and simulated/production label. Financial panels must remain disabled/marked unavailable until authoritative ledgers exist. Avoid vanity totals and misleading sample-to-production extrapolation.
