# Referral & Engagement Analytics

Engagement can be studied using sessions, feature events, daily activity, task activity and feature usage. Use qualifying user-initiated events, exclude system noise, and define activity windows/timezone. Feature adoption = distinct users using a feature / eligible users; eligibility must be defined.

Referral data in the sample is partial: user acquisition/referral source attributes and referral activity indicators exist, but no complete referral relationship ledger. Proposed referral_id links referrer_user_id and referred_user_id, with invite, attribution, qualification and reward timestamps/status.

KPIs: referral invite volume, attributed signup conversion, qualification rate, time to qualify, referral reward issuance and engagement by acquisition cohort. Do not treat `referral_source_detail` alone as proof of a complete referral chain.
