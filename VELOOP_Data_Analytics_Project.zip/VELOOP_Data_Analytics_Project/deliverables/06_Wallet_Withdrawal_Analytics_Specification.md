# Wallet & Withdrawal Analytics Specification

**Coverage gap:** No dedicated wallet transaction or withdrawal request workbook/table was supplied. Do not report wallet balances, withdrawal volumes, success rates, revenue or payout performance from these files.

## Wallet model
Use an immutable ledger with transaction_id, wallet_id, user_id, transaction_type, amount, currency/unit, balance_before, balance_after, status, posted_at, reference_type/id and idempotency_key. Credits/debits/reversals must be separate auditable entries. Reconcile opening balance + credits − debits = closing balance under a documented sign convention.

## Withdrawal lifecycle
Requested → under_review → approved/rejected → processing → paid/failed → reversed where applicable. Capture withdrawal_id, requested/approved amount, currency, requested/reviewed/processed/paid timestamps, status, failure reason and restricted provider reference.

## KPIs
Wallet credits/debits, reconciliation difference, withdrawal request count, approval rate, paid success rate, processing time, failure/reversal rate. These remain proposed/not calculable until authoritative data is available.

## Controls
Server-authoritative state, idempotency, role-restricted access, audit trail, no payment credentials in analytics, reconciliation and exception queue.
