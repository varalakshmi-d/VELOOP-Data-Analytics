# User Analytics Specification

## Lifecycle
Registration → verification → onboarding → first meaningful activity → repeat activity → dormant / reactivated / suspended / deleted. Use immutable `user_id`; preserve registration timestamp, acquisition source, referral attribution, device/platform, account state, consent and marketing preference.

## Core dimensions
User, registration cohort, acquisition channel, geography at approved granularity, platform/device, account status, verification status, onboarding status and consent state. Avoid exposing name/email in analytical marts; use pseudonymous IDs.

## Required events
`account_registered`, `login_succeeded`, `login_failed`, `email_verification_completed`, `onboarding_completed`, `session_started`, `session_ended`.

## Metrics
Registrations, verified users/rate, onboarding completion, first activity conversion, DAU/WAU/MAU and cohort retention. Define qualifying activity and timezone before production. Do not calculate retention from a static snapshot without a clear cohort/activity window.

## Data controls
Unique user ID; valid UTC timestamps; controlled acquisition/status enums; consent change history; no unnecessary PII in analytics; source-to-warehouse reconciliation.
