# Assumption & Verification Register

The register is maintained in `Assumption_Verification_Register.xlsx`. Key verification items: production event implementation; authoritative identity/session source; meaning and exchange rules for VE/Gems/Tokens; reward eligibility and reversal rules; wallet source of truth; withdrawal lifecycle/provider; referral attribution/qualification; support ticket source; consent semantics; timezone; metric activity definitions. Every proposal remains unconfirmed until Product/Engineering owner signs off.
