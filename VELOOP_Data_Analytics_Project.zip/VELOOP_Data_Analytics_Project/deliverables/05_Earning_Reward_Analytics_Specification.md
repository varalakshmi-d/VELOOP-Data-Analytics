# Earning & Reward Analytics Specification

Model task and reward lifecycles separately. Task attempt grain: one `activity_id` per attempt. Reward grain: one `reward_id` per issued reward. Capture viewed, started, completed, failed, issued, claimed, expired and reversed transitions with timestamps and reason codes.

Required reward ledger fields include reward_id, user_id, reward_type, reward_status, reward_value, reward_unit, issued_at, claimed_at, expires_at, source_activity_id and reversal reference. XP should be represented as ledger movements, not only a mutable balance.

KPIs: task view-to-start, start-to-complete, failure rate, completion time, reward issuance volume, claim rate, expiry and reversal rates, XP credits by unit. The supplied sample has task activity and aggregate reward/XP flags but no complete reward ledger; monetary/economic reward totals are therefore not calculable.

Controls: idempotent issuance, unique source activity, allowed state transitions, non-negative amounts, unit consistency, immutable ledger and reconciliation.
