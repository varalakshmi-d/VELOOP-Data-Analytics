import streamlit as st
import pandas as pd
from pathlib import Path
st.set_page_config(page_title="VELOOP Analytics Blueprint",layout="wide")
st.title("VELOOP Rewards — Simulated Analytics Explorer")
st.warning("SIMULATED / FICTIONAL DATA ONLY. These are not actual VELOOP production metrics.")
path=Path(__file__).resolve().parents[1]/"data"/"VELOOP_Simulated_User_Behavior_1000.xlsx"
if path.exists():
    xls=pd.ExcelFile(path); sheet=st.selectbox("Select dataset",xls.sheet_names); df=pd.read_excel(xls,sheet_name=sheet)
    c1,c2,c3=st.columns(3); c1.metric("Rows",f"{len(df):,}"); c2.metric("Columns",len(df.columns)); c3.metric("Duplicate rows",int(df.duplicated().sum()))
    st.dataframe(df.head(500),use_container_width=True)
    st.caption("Exploratory preview only. Use approved metric definitions before production reporting.")
else: st.error("Dataset not found. Place the supplied workbook in the data/ folder.")
