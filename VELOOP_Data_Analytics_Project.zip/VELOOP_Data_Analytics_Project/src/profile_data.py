"""Reproducible profiling for VELOOP simulated internship datasets.
All outputs are simulated and must not be represented as production metrics.
Run: python src/profile_data.py --data-dir data --output-dir outputs
"""
import argparse, os, glob
import pandas as pd

def profile_workbook(path):
    xls = pd.ExcelFile(path)
    rows=[]
    for sheet in xls.sheet_names:
        df=pd.read_excel(xls, sheet_name=sheet)
        rows.append({'workbook':os.path.basename(path),'sheet':sheet,'rows':len(df),'columns':len(df.columns),'duplicate_rows':int(df.duplicated().sum()),'missing_cells':int(df.isna().sum().sum())})
    return rows

def main():
    p=argparse.ArgumentParser(); p.add_argument('--data-dir',default='data'); p.add_argument('--output-dir',default='outputs'); a=p.parse_args()
    os.makedirs(a.output_dir,exist_ok=True); rows=[]
    for path in glob.glob(os.path.join(a.data_dir,'*.xlsx')): rows.extend(profile_workbook(path))
    out=os.path.join(a.output_dir,'sheet_profile.csv'); pd.DataFrame(rows).to_csv(out,index=False); print('SIMULATED DATA profile written:',out)
if __name__=='__main__': main()
