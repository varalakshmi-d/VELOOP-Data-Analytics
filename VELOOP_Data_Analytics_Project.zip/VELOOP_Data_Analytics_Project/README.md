# VELOOP Rewards — Data Analyst Internship Task 01

> **SIMULATED DATA — FOR ANALYTICAL WORK ONLY.** All supplied workbook records are fictional. Nothing in this repository represents actual VELOOP users, earnings, withdrawals, revenue, retention, conversion or company performance. Proposed tracking is not evidence of production implementation.

## Objective
Product analytics, data readiness and data management blueprint based on the official internship task PDF and two supplied simulated Excel workbooks.

## Tools
Python 3.10+, pandas, numpy, openpyxl; optional Streamlit for the exploratory preview.

## Datasets
- `data/VELoop_Rewards_Data_01.xlsx`: clean/messy user profiles, source dictionary, synthetic summary and status notes.
- `data/VELOOP_Simulated_User_Behavior_1000.xlsx`: users, sessions, feature events, daily activity, task activity, milestones, feature usage, dictionary and event audit.

## Structure
- `deliverables/`: 21-task deliverable documents and core specification workbooks.
- `outputs/`: reproducible profiling, DQ issue register, sheet inventory and summary.
- `reports/`: consolidated report and executive report.
- `src/`: reproducible Python profiling code.
- `dashboards/`: Streamlit exploratory app and dashboard blueprint HTML.
- `diagrams/`: Mermaid ER model and pipeline architecture.

## Setup and run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python src/profile_data.py --data-dir data --output-dir outputs
streamlit run dashboards/app.py
```

## Deliverables checklist
See `reports/Deliverables_Checklist.md`.

## Important limitations
The supplied data does not include dedicated wallet transaction, withdrawal, reward ledger, referral relationship or support ticket tables. Those models and KPIs are proposals and are marked accordingly. Confirm production schemas, event implementation, business rules, units, eligibility and privacy obligations with VELOOP Product/Engineering before use.
